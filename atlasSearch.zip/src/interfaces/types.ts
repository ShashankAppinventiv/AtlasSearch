export type AcceptAny = any;

export type StringOrNumber = string | number;

export type AcceptNullOrObject = {} | null;
